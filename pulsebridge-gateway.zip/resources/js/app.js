window.onload = function() {
  setTimeout(function() {
    window.location.href = 'index.php';
  }, 0);
}
